#include <iostream>
#include "time.h"

#define map_width 5
#define map_height 5
#define tile_width 1
#define tile_height 1

void main()
{
	srand(time(0));
	bool map[map_width * map_height]=
	{
		1,1,1,1,1,
		1,0,0,0,0,
		1,0,1,1,1,
		1,0,1,0,0,
		1,0,1,0,0,
	};
	bool coll[map_width * map_height] =
	{
		0,0,0,0,0,
		0,0,0,0,0,
		0,0,0,0,0,
		0,0,0,0,0,
		0,0,0,0,0,
	};
	printf("------------------------------------original map\n");
	for (unsigned int y = 0; y < map_height; ++y)
	{
		for (unsigned int x = 0; x < map_width; ++x)
		{
			printf("[%d]", map[x + y * map_width]);
		}
		printf("\n");
	}
	printf("------------------------------------normal colliders\n");
	for (unsigned int y = 0; y < map_height; ++y)
	{
		for (unsigned int x = 0; x < map_width; ++x)
		{
			if (map[x + y * map_width])
			{
				printf("collider_rect %d %d %d %d\n", x * tile_width, y * tile_height, tile_width, tile_height);
			}
		}
	}
	printf("------------------------------------horizontal compressed colliders\n");
	for (unsigned int y = 0; y < map_height; ++y)
	{
		for (unsigned int x = 0; x < map_width; ++x)
		{
			if (map[x + y * map_width])
			{
				unsigned int original_x = x;
				while (map[x + y * map_width]) ++x;
				printf("collider_rect %d %d %d %d\n", original_x * tile_width, y * tile_height, x * tile_width, tile_height);
			}
		}
	}
	printf("------------------------------------compressed colliders\n");
	for (unsigned int y = 0; y < map_height; ++y)
	{
		for (unsigned int x = 0; x < map_width; ++x)
		{
			if (map[x + y * map_width] && !coll[x + y * map_width])
			{
				unsigned int i_x = 0;
				unsigned int i_y = 0;

				while (map[(x + i_x) + y * map_width] && !coll[(x + i_x) + y * map_width]) ++i_x;

				while (map[x + (y + i_y) * map_width] && !coll[x + (y + i_y) * map_width]) ++i_y;

				if (i_x > i_y)
				{
					--i_x;
					printf("collider_rect %d %d %d %d\n", x * tile_width, y * tile_height, (x + i_x) * tile_width, tile_height);
					++i_x;
					for (unsigned int i = x; i < x + i_x; ++i) coll[i + y * map_width] = 1;
				}
				if (i_y > i_x)
				{
					--i_y;
					printf("collider_rect %d %d %d %d\n", x * tile_width, y * tile_height, tile_width, (y + i_y) * tile_height);
					++i_y;
					for (unsigned int i = y; i < y + i_y; ++i) coll[x + i * map_width] = 1;
				}
			}
		}
	}
	printf("------------------------------------checked map\n");
	for (unsigned int y = 0; y < map_height; ++y)
	{
		for (unsigned int x = 0; x < map_width; ++x)
		{
			printf("[%d]", coll[x + y * map_width]);
		}
		printf("\n");
	}
}
