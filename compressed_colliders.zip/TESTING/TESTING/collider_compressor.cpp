#include <iostream>
#include "time.h"

#define tile_width 1
#define tile_height 1

void print_map(bool* map, unsigned int width, unsigned int height)
{
	for (unsigned int y = 0; y < width; ++y)
	{
		for (unsigned int x = 0; x < height; ++x)
		{
			printf("|%d", map[x + y * width]);
		}
		printf("|\n");
	}
}

unsigned int normal_colliders(bool* map, unsigned int width, unsigned int height, bool debug = false)
{
	unsigned int collider_count = 0;
	for (unsigned int y = 0; y < height; ++y)
	{
		for (unsigned int x = 0; x < width; ++x)
		{
			if (map[x + y * width])
			{
				if (debug) printf("collider_rect %d %d %d %d\n", x * tile_width, y * tile_height, tile_width, tile_height);
				++collider_count;
			}
		}
	}
	return collider_count;
}

unsigned int compressed_colliders(bool* map, bool* coll, unsigned int width, unsigned int height, bool debug = false)
{
	unsigned int collider_count = 0;
	for (unsigned int y = 0; y < height; ++y)
	{
		for (unsigned int x = 0; x < width; ++x)
		{
			if (map[x + y * width] && !coll[x + y * width])
			{
				unsigned int i_x = 1;
				unsigned int i_y = 1;

				/*&& (x + i_x) < width ::: CHECK PRIORITY AXIS TO AVOID ROW/COLUMN OVERLOAD*/
				while (map[(x + i_x) + y * width] && !coll[(x + i_x) + y * width] && (x + i_x) < width) ++i_x;

				while (map[x + (y + i_y) * width] && !coll[x + (y + i_y) * width]) ++i_y;

				if (i_x >= i_y)
				{
					if (i_x > i_y) if (debug) printf("(i_x > i_y) at [%d][%d] ::: ", x, y);

					if (i_x == i_y) if (debug) printf("(i_x == i_y) at [%d][%d] ::: (priority case) ", x, y);

					if (debug) printf("collider_rect { %d,%d,%d,%d }\n", x * tile_width, y * tile_height, (i_x)*tile_width, tile_height);
					++collider_count;

					for (unsigned int i = x; i < x + i_x; ++i)
					{
						if (debug) printf("coll at [%d][%d]\n", i, y);
						coll[i + y * width] = 1;
					}
				}
				if (i_y > i_x)
				{
					if (debug) printf("(i_y > i_x) at [%d][%d] ::: ", x, y);

					if (debug) printf("collider_rect { %d,%d,%d,%d }\n", x * tile_width, y * tile_height, tile_width, (i_y)*tile_height);
					++collider_count;

					for (unsigned int i = y; i < y + i_y; ++i)
					{
						if (debug) printf("coll at [%d][%d]\n", x, i);
						coll[x + i * width] = 1;
					}
				}
			}
		}
	}
	return collider_count;
}

int main()
{
	srand(time(0));

	//fix width/height ambiguity
	const unsigned int width = 10;
	const unsigned int height = 10;

	while (1)
	{
		//bool* map = new bool[width * height];//{ 0,1,1,0, };
		bool map[width * height];

		bool coll[width * height];

		float max_space_saved = 0;
		unsigned int iterations = 0;
		float total_space_saved = 0;

		while (iterations < 100)
		{
			system("cls");
			++iterations;

			for (unsigned int i = 0; i < width * height; ++i)
			{
				map[i] = bool(rand() % 2);
			}

			memset(coll, 0, sizeof(coll));

			printf("\n------------------------------------original map\n\n");
			print_map(map, width, height);

			printf("\n------------------------------------normal colliders\n\n");
			unsigned int normal = normal_colliders(map, width, height);

			printf("\n------------------------------------compressed colliders\n\n");
			unsigned int compressed = compressed_colliders(map, coll, width, height);

			printf("\n------------------------------------checked map\n\n");
			//print_map(coll, width, height);

			float saved_space = 100 * (1 - ((float)compressed / (float)normal));
			printf("\ncompression ratio %d:%d (saved %.2f%%)\n\n", normal, compressed, saved_space);

			if (max_space_saved < saved_space) max_space_saved = saved_space;
			total_space_saved += saved_space;
			printf("max_space_saved %.2f%%\naverage_space_saved %.2f%%\n", max_space_saved, total_space_saved / iterations);
			printf("\niteration %d\n\n", iterations);
		}
		system("pause");
	}

	return 0;
}
